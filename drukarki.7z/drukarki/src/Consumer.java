import static java.lang.Thread.sleep;

/**
 * Created by Madzia on 24.10.2017.
 */



class Consumer implements Runnable
{
    //private Buffer buffer;
    private PrintersMonitor monitor;
    private int myNr;
    private Drukarnia drukarnia;

    //public Consumer(PrintersMonitor bbuffer, Buffer buffer, int n)
    public Consumer(PrintersMonitor monitor, int n, Drukarnia d)
    {
        this.monitor = monitor;
        //this.buffer = buffer;
        myNr = n;
        drukarnia = d;
    }
    public void run()
    {

        for(int j = 0; j<2; j++)
        {
            createTask();
            int printerNr = 0;
            try {
                printerNr = monitor.take();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            drukarnia.print(printerNr);
            try {
                sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("Consumer " + myNr +  "printed in : " + printerNr);
            try {
                monitor.put(printerNr);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }

    private void createTask() {

        System.out.println("Utworzono zadanie"+myNr);
    }

}


