import static java.lang.Thread.sleep;

/**
 * Created by Madzia on 24.10.2017.
 */
public class Printer implements Runnable {

    //private PrintersMonitor monitor;
    private int myNr;


    Printer(PrintersMonitor monitor, int n)
    {
        //this.monitor = monitor;
        //this.buffer = buffer;
        myNr = n;
    }
    public void run()
    {
        try {
            sleep(1500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(myNr + "Drukuję...");

    }
}
