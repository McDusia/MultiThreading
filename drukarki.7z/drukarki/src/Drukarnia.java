/**
 * Created by Madzia on 24.10.2017.
 */
public class Drukarnia {

    Printer[] printers;
    Consumer[] consumers;
    Thread[] printersThreads = new Thread[10];
    Thread[] consumerThreads = new Thread[10];


    Drukarnia(Printer[] printers, Consumer[] consumers ) {
            this.printers = printers;
            this.consumers = consumers;
    }

    public static void main(String[] args) throws Exception
    {
        int qnt = 10; //10 drukarek
        Drukarnia d = new Drukarnia(new Printer[qnt],new Consumer[qnt]);
        PrintersMonitor monitor = new PrintersMonitor();
        for(int i = 0; i< 10; i++)
            monitor.put(i);


        for(int i = 0;i<10;i++) {
            d.printers[i] = new Printer(monitor, i);
            d.printersThreads[i]= new Thread(d.printers[i]);
            d.consumers[i] = new Consumer(monitor, i, d);
            d.consumerThreads[i] = new Thread(d.consumers[i]);
        }


        for(int i = 0;i<10;i++) {
            //d.printersThreads[i].start();
            d.consumerThreads[i].start();
        }


        for(int i = 0;i<10;i++) {
            d.printersThreads[i].join();
            d.consumerThreads[i].join();
        }


    }

    public void print(int printerNr) {


        printersThreads[printerNr].start();
    }
}
